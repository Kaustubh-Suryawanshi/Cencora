package com.Inheritance;

@FunctionalInterface
interface i1{
    public void method1();
}

public class Functional_InterfaceDemo {
}
